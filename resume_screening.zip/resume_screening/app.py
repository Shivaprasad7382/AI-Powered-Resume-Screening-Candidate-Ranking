"""
AI-Powered Resume Screening & Candidate Ranking System
Flask + MySQL + NLP (TF-IDF / cosine similarity)
"""
from flask import Flask, request, jsonify, render_template
import mysql.connector
import logging, json, re, math
from datetime import datetime
from collections import Counter

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, handlers=[logging.FileHandler("resume.log"), logging.StreamHandler()])
logger = logging.getLogger(__name__)

DB_CONFIG = {"host":"localhost","user":"root","password":"your_password","database":"resume_db"}

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

def init_db():
    conn = get_db(); cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS job_postings(
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        description TEXT,
        required_skills TEXT,
        experience_years INT DEFAULT 0,
        department VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS candidates(
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100), email VARCHAR(150),
        skills TEXT, experience_years INT DEFAULT 0,
        education VARCHAR(200), resume_text TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS applications(
        id INT AUTO_INCREMENT PRIMARY KEY,
        candidate_id INT, job_id INT,
        match_score DECIMAL(5,4) DEFAULT 0,
        skill_match_pct DECIMAL(5,2) DEFAULT 0,
        experience_match BOOLEAN DEFAULT FALSE,
        matched_skills JSON, missing_skills JSON,
        rank_position INT,
        status ENUM('Applied','Shortlisted','Interview','Rejected','Hired') DEFAULT 'Applied',
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(candidate_id) REFERENCES candidates(id),
        FOREIGN KEY(job_id) REFERENCES job_postings(id))""")
    conn.commit()
    cursor.execute("SELECT COUNT(*) FROM job_postings")
    if cursor.fetchone()[0] == 0:
        _seed(cursor); conn.commit()
    cursor.close(); conn.close()

def _seed(cursor):
    jobs = [
        ("Python Backend Developer", "We need a Python developer with Flask and MySQL experience to build REST APIs and microservices.",
         "Python,Flask,MySQL,REST API,Git,Docker", 2, "Engineering"),
        ("Data Scientist", "Seeking a data scientist skilled in machine learning, Python, and statistical analysis.",
         "Python,Machine Learning,Pandas,NumPy,Scikit-learn,SQL,TensorFlow", 3, "Data Science"),
        ("Full Stack Developer", "Full stack role requiring React frontend and Python backend expertise.",
         "Python,React,JavaScript,Flask,MySQL,HTML,CSS,Git", 2, "Engineering"),
    ]
    for j in jobs:
        cursor.execute("INSERT INTO job_postings(title,description,required_skills,experience_years,department) VALUES(%s,%s,%s,%s,%s)", j)

    candidates = [
        ("Aarav Shah","aarav@email.com","Python,Flask,MySQL,REST API,Git,Docker,Linux",3,"B.Tech Computer Science",
         "Experienced Python developer with 3 years building Flask APIs and MySQL databases. Proficient in Docker and Git."),
        ("Priya Patel","priya@email.com","Python,Machine Learning,Pandas,NumPy,Scikit-learn,TensorFlow,SQL",4,"M.Sc Data Science",
         "Data scientist with 4 years experience in ML, deep learning and statistical modeling using Python."),
        ("Rahul Verma","rahul@email.com","JavaScript,React,HTML,CSS,Node.js",2,"B.Tech IT",
         "Frontend developer skilled in React and JavaScript with 2 years experience building web applications."),
        ("Sneha Iyer","sneha@email.com","Python,Flask,React,MySQL,Git,JavaScript",2,"B.Tech CSE",
         "Full stack developer with Python and React expertise, 2 years experience in web development."),
        ("Arjun Nair","arjun@email.com","Python,Pandas,SQL,Tableau,Excel",1,"B.Sc Statistics",
         "Junior data analyst with Python and SQL skills. 1 year experience in data analysis and visualization."),
    ]
    for c in candidates:
        cursor.execute("INSERT INTO candidates(name,email,skills,experience_years,education,resume_text) VALUES(%s,%s,%s,%s,%s,%s)", c)

# ── NLP Utilities ──
def tokenize(text):
    return re.findall(r'\b[a-zA-Z][a-zA-Z0-9+#\.]*\b', text.lower())

def tfidf_similarity(text1, text2):
    t1, t2 = tokenize(text1), tokenize(text2)
    vocab = list(set(t1 + t2))
    def tf(tokens, word): return tokens.count(word) / len(tokens) if tokens else 0
    def tfidf_vec(tokens):
        return [tf(tokens, w) * (1 + math.log(2 / (1 + (1 if w not in tokens else 0)))) for w in vocab]
    v1, v2 = tfidf_vec(t1), tfidf_vec(t2)
    dot = sum(a*b for a,b in zip(v1,v2))
    mag1 = math.sqrt(sum(a**2 for a in v1))
    mag2 = math.sqrt(sum(b**2 for b in v2))
    return round(dot / (mag1 * mag2), 4) if mag1 and mag2 else 0.0

def compute_skill_match(candidate_skills_str, required_skills_str):
    cand = [s.strip().lower() for s in candidate_skills_str.split(",")]
    req  = [s.strip().lower() for s in required_skills_str.split(",")]
    matched = [s for s in req if any(s in c or c in s for c in cand)]
    missing = [s for s in req if s not in matched]
    pct = round(len(matched)/len(req)*100, 1) if req else 0
    return matched, missing, pct

@app.route("/")
def dashboard():
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT COUNT(*) AS total FROM candidates"); total_c = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) AS total FROM job_postings"); total_j = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) AS total FROM applications WHERE status='Shortlisted'"); shortlisted = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) AS total FROM applications WHERE status='Hired'"); hired = cursor.fetchone()["total"]
    cursor.execute("""SELECT a.*, c.name, c.skills, c.experience_years AS cand_exp, j.title AS job_title
                      FROM applications a
                      JOIN candidates c ON a.candidate_id=c.id
                      JOIN job_postings j ON a.job_id=j.id
                      ORDER BY a.match_score DESC LIMIT 15""")
    apps = cursor.fetchall()
    cursor.execute("SELECT * FROM job_postings ORDER BY created_at DESC"); jobs = cursor.fetchall()
    cursor.close(); conn.close()
    for a in apps:
        for f in ["applied_at"]:
            if a.get(f): a[f] = a[f].isoformat()
        for f in ["match_score","skill_match_pct"]:
            if a.get(f): a[f] = float(a[f])
    return render_template("dashboard.html", total_c=total_c, total_j=total_j,
                           shortlisted=shortlisted, hired=hired, apps=apps, jobs=jobs)

@app.route("/api/screen", methods=["POST"])
def screen_candidates():
    data = request.get_json()
    job_id = data.get("job_id")
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM job_postings WHERE id=%s", (job_id,))
    job = cursor.fetchone()
    if not job: return jsonify({"error":"Job not found"}), 404
    cursor.execute("SELECT * FROM candidates")
    candidates = cursor.fetchall()
    results = []
    for c in candidates:
        text_score = tfidf_similarity(c["resume_text"] or "", job["description"] or "")
        matched, missing, skill_pct = compute_skill_match(c["skills"] or "", job["required_skills"] or "")
        exp_match = c["experience_years"] >= job["experience_years"]
        final_score = round(text_score * 0.4 + (skill_pct/100) * 0.5 + (0.1 if exp_match else 0), 4)
        cursor.execute("""INSERT INTO applications(candidate_id,job_id,match_score,skill_match_pct,
                          experience_match,matched_skills,missing_skills)
                          VALUES(%s,%s,%s,%s,%s,%s,%s)
                          ON DUPLICATE KEY UPDATE match_score=%s,skill_match_pct=%s""",
                       (c["id"],job_id,final_score,skill_pct,exp_match,
                        json.dumps(matched),json.dumps(missing),final_score,skill_pct))
        results.append({"candidate_id":c["id"],"name":c["name"],"match_score":final_score,
                        "skill_match_pct":skill_pct,"matched_skills":matched,"missing_skills":missing})
    conn.commit()
    results.sort(key=lambda x: x["match_score"], reverse=True)
    for i,r in enumerate(results):
        cursor.execute("UPDATE applications SET rank_position=%s WHERE candidate_id=%s AND job_id=%s",
                       (i+1,r["candidate_id"],job_id))
    conn.commit()
    top3 = results[:3]
    for r in top3:
        cursor.execute("UPDATE applications SET status='Shortlisted' WHERE candidate_id=%s AND job_id=%s",
                       (r["candidate_id"],job_id))
    conn.commit(); cursor.close(); conn.close()
    return jsonify({"job_title":job["title"],"ranked_candidates":results}), 200

@app.route("/api/jobs", methods=["GET"])
def get_jobs():
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM job_postings ORDER BY created_at DESC")
    jobs = cursor.fetchall(); cursor.close(); conn.close()
    for j in jobs:
        if j.get("created_at"): j["created_at"] = j["created_at"].isoformat()
    return jsonify({"jobs": jobs}), 200

@app.route("/api/candidates", methods=["POST"])
def add_candidate():
    data = request.get_json()
    conn = get_db(); cursor = conn.cursor()
    cursor.execute("INSERT INTO candidates(name,email,skills,experience_years,education,resume_text) VALUES(%s,%s,%s,%s,%s,%s)",
                   (data["name"],data["email"],data.get("skills",""),data.get("experience_years",0),
                    data.get("education",""),data.get("resume_text","")))
    conn.commit(); cid = cursor.lastrowid; cursor.close(); conn.close()
    return jsonify({"message":"Candidate added","id":cid}), 201

if __name__ == "__main__":
    init_db(); app.run(debug=True, port=5011)
